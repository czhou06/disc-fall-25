export const CURRENT_USER = {
    first_name: "Chris",
    last_name: "Zhou",
    email: "chriszhou2028@u.northwestern.edu",
    id: 1
};